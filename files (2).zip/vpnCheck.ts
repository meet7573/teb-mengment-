// VPN / proxy detection for student requests.
// Uses proxycheck.io (works without a key at a lower free rate limit; set
// PROXYCHECK_API_KEY env var for a higher free-tier limit — sign up at
// https://proxycheck.io/). Results are cached in-memory per IP so that
// "check on every action" does not mean "call the API on every action".

type CacheEntry = { isVpn: boolean; expiresAt: number };

const CACHE_TTL_MS = 20 * 60_000; // 20 minutes
const vpnCache = new Map<string, CacheEntry>();
const PROXYCHECK_KEY = process.env.PROXYCHECK_API_KEY || '';

function isPrivateOrLocalIp(ip: string): boolean {
  if (!ip || ip === 'unknown') return true;
  if (ip === '::1' || ip.startsWith('127.')) return true;
  if (ip.startsWith('10.') || ip.startsWith('192.168.')) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(ip)) return true;
  return false;
}

export function extractClientIp(req: { headers: Record<string, unknown>; ip?: string; socket?: { remoteAddress?: string } }): string {
  const forwardedHeader = req.headers['x-forwarded-for'];
  const forwarded = Array.isArray(forwardedHeader) ? forwardedHeader[0] : forwardedHeader;
  const first = String(forwarded ?? '').split(',')[0].trim();
  return first || req.ip || req.socket?.remoteAddress || 'unknown';
}

// Returns true only when the IP is confidently flagged as VPN/proxy.
// Fails open (returns false) on any error, timeout, or local/dev IP so a
// flaky detection API can never block or slow down student check-in/out.
export async function checkVpn(ip: string): Promise<boolean> {
  if (isPrivateOrLocalIp(ip)) return false;

  const cached = vpnCache.get(ip);
  if (cached && cached.expiresAt > Date.now()) return cached.isVpn;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    const keyParam = PROXYCHECK_KEY ? `&key=${encodeURIComponent(PROXYCHECK_KEY)}` : '';
    const response = await fetch(`https://proxycheck.io/v2/${encodeURIComponent(ip)}?vpn=1${keyParam}`, { signal: controller.signal });
    clearTimeout(timeout);
    if (!response.ok) throw new Error(`proxycheck returned ${response.status}`);
    const data: any = await response.json();
    const entry = data?.[ip];
    const isVpn = data?.status === 'ok' && String(entry?.proxy ?? '').toLowerCase() === 'yes';
    vpnCache.set(ip, { isVpn, expiresAt: Date.now() + CACHE_TTL_MS });
    return isVpn;
  } catch (error) {
    console.error('VPN check failed (failing open):', error);
    return false;
  }
}
