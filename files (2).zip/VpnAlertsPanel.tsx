import React, { useEffect, useState } from 'react';
import { ShieldAlert, Check } from 'lucide-react';

interface VpnNotification { id: string; studentId: string | null; ip: string; path: string; timestamp: string; }

export const VpnAlertsPanel: React.FC = () => {
  const [items, setItems] = useState<VpnNotification[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const token = localStorage.getItem('stm_admin_session_token') || '';
    if (!token) return;
    try {
      const r = await fetch('/api/admin/notifications', { headers: { Authorization: `Bearer ${token}` } });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(d?.error || 'Could not load notifications.');
      setItems(Array.isArray(d.notifications) ? d.notifications : []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load notifications.');
    }
  };

  useEffect(() => {
    load();
    const timer = window.setInterval(load, 10000);
    return () => window.clearInterval(timer);
  }, []);

  const acknowledge = async (id: string) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('stm_admin_session_token') || '';
      const r = await fetch(`/api/admin/notifications/${encodeURIComponent(id)}/read`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!r.ok) throw new Error('Could not update notification.');
      setItems(current => current.filter(item => item.id !== id));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not update notification.');
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0 && !error) return null;

  return (
    <section className="mt-6 bg-white rounded-3xl border border-amber-200 shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-amber-200 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            VPN Activity Alerts
          </h3>
          <p className="text-xs text-slate-500 mt-1">Detected on student-side requests. Students are not notified.</p>
        </div>
        <span className="rounded-full bg-amber-50 text-amber-700 px-3 py-1 text-xs font-bold">{items.length} New</span>
      </div>
      {error && <div className="m-4 rounded-xl bg-red-50 text-red-700 px-4 py-3 text-sm">{error}</div>}
      <div className="divide-y divide-slate-100">
        {items.map(item => (
          <div key={item.id} className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="font-bold text-slate-900">{item.studentId ? `Student ID: ${item.studentId}` : 'Unidentified request'}</p>
              <p className="text-xs text-slate-500 mt-1">IP: {item.ip} • {item.path} • {new Date(item.timestamp).toLocaleString()}</p>
            </div>
            <button
              disabled={loading}
              onClick={() => acknowledge(item.id)}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-50 text-slate-700 font-semibold disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              Acknowledge
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};
