import express from 'express';
import { createHash, randomUUID } from 'node:crypto';

type Ctx = { supabaseUrl?: string; supabaseKey?: string };
const SUPER_ADMIN_USERNAME = 'superadmin';
const SUPER_ADMIN_EMAIL = 'meetdevani2003@gmail.com';
const adminSessions = new Map<string, { email: string; expiresAt: number }>();
function hash(value: string) { return createHash('sha256').update(value).digest('hex'); }
function configured(ctx: Ctx) { return Boolean(ctx.supabaseUrl && ctx.supabaseKey); }
async function db(ctx: Ctx, pathname: string, options: RequestInit = {}) { if (!configured(ctx)) throw new Error('Supabase is not configured'); return fetch(`${ctx.supabaseUrl!.replace(/\/$/, '')}/rest/v1/${pathname}`, { ...options, headers: { apikey: ctx.supabaseKey!, Authorization: `Bearer ${ctx.supabaseKey!}`, 'Content-Type': 'application/json', ...(options.headers || {}) } }); }
async function rows(ctx: Ctx, collection: string) { const r = await db(ctx, `app_data?collection=eq.${encodeURIComponent(collection)}&select=data&order=updated_at.asc`); if (!r.ok) throw new Error(`Read ${collection} failed: ${r.status}`); return (await r.json()).map((x: any) => x.data); }
async function insert(ctx: Ctx, collection: string, id: string, data: any) { const r = await db(ctx, 'app_data', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ collection, id, data }) }); if (!r.ok) throw new Error(`Insert ${collection} failed: ${r.status} ${await r.text()}`); }
async function patch(ctx: Ctx, collection: string, id: string, data: any) { const r = await db(ctx, `app_data?collection=eq.${encodeURIComponent(collection)}&id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ data, updated_at: new Date().toISOString() }) }); if (!r.ok) throw new Error(`Update ${collection} failed: ${r.status} ${await r.text()}`); }
async function sessionFrom(ctx: Ctx, req: express.Request) { const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim(); if (!token) return null; const memory = adminSessions.get(token); if (memory && memory.expiresAt > Date.now() && memory.email === SUPER_ADMIN_EMAIL) return { token, email: memory.email }; try { const records = await rows(ctx, 'adminSessions'); const record = records.find((x: any) => String(x?.id) === token && String(x?.email || '').toLowerCase() === SUPER_ADMIN_EMAIL && !x?.revokedAt && new Date(x?.expiresAt || 0).getTime() > Date.now()); if (!record) return null; adminSessions.set(token, { email: SUPER_ADMIN_EMAIL, expiresAt: new Date(record.expiresAt).getTime() }); return { token, email: SUPER_ADMIN_EMAIL }; } catch { return null; } }
export function requireAdminSession(ctx: Ctx) { return async (req: express.Request, res: express.Response, next: express.NextFunction) => { if (!configured(ctx)) return res.status(503).json({ error: 'Admin authentication service is not configured.' }); const session = await sessionFrom(ctx, req); if (!session) return res.status(401).json({ error: 'Admin session required. Please login again.' }); return next(); }; }

export function createAdminRoutes(ctx: Ctx) {
  const router = express.Router();
  // Step 1: validate the fixed Super Admin credentials and send a one-time 6-digit OTP.
  router.post('/login/request-otp', async (req, res) => {
    const username = String(req.body?.username || '').trim().toLowerCase();
    const email = String(req.body?.email || '').trim().toLowerCase();
    if (username !== SUPER_ADMIN_USERNAME || email !== SUPER_ADMIN_EMAIL) {
      return res.status(403).json({ error: 'The user name or email ID is not authorized to access the Admin Dashboard.' });
    }
    if (!configured(ctx)) return res.status(503).json({ error: 'Admin authentication service is not configured.' });

    // Do not create any OTP state when SMTP is unavailable.
    const transport = getMailTransport();
    if (!transport) return res.status(503).json({ error: 'Could not send the login code. SMTP is not configured correctly on the server.' });

    const existing = pendingOtps.get(email);
    if (existing && Date.now() - existing.lastSentAt < OTP_RESEND_COOLDOWN_MS) {
      const waitSeconds = Math.ceil((OTP_RESEND_COOLDOWN_MS - (Date.now() - existing.lastSentAt)) / 1000);
      return res.status(429).json({ error: `Please wait ${waitSeconds}s before requesting another code.` });
    }

    const otp = generateOtp();
    const otpHash = hash(otp);
    const expiresAt = Date.now() + OTP_TTL_MS;
    const lastSentAt = Date.now();

    try {
      await sendOtpEmail(otp, email);
    } catch (e) {
      console.error('Failed to send admin OTP email', e);
      return res.status(503).json({ error: 'Could not send the login code. SMTP is not configured correctly on the server.' });
    }

    pendingOtps.set(email, { hash: otpHash, expiresAt, attempts: 0, lastSentAt });

    // Audit trail only: never store the raw OTP.
    try {
      const id = randomUUID();
      await insert(ctx, 'adminOtps', id, {
        id,
        email,
        otpHash,
        expiresAt: new Date(expiresAt).toISOString(),
        createdAt: new Date(lastSentAt).toISOString(),
        used: false,
      });
    } catch (e) {
      console.error('Failed to persist OTP audit record', e);
    }

    return res.json({ ok: true, message: `A 6-digit code was sent to ${email}.`, expiresInSeconds: OTP_TTL_MS / 1000 });
  });

  // Step 2: verify the OTP and only then issue the normal admin session.
  router.post('/login/verify-otp', async (req, res) => {
    const username = String(req.body?.username || '').trim().toLowerCase();
    const email = String(req.body?.email || '').trim().toLowerCase();
    const otp = String(req.body?.otp || '').trim();
    if (username !== SUPER_ADMIN_USERNAME || email !== SUPER_ADMIN_EMAIL) {
      return res.status(403).json({ error: 'The user name or email ID is not authorized to access the Admin Dashboard.' });
    }
    if (!/^\d{6}$/.test(otp)) return res.status(400).json({ error: 'Enter the 6-digit code sent to your email.' });
    if (!configured(ctx)) return res.status(503).json({ error: 'Admin authentication service is not configured.' });

    const pending = pendingOtps.get(email);
    if (!pending) return res.status(400).json({ error: 'No login code is pending. Please request a new one.' });
    if (Date.now() > pending.expiresAt) {
      pendingOtps.delete(email);
      return res.status(400).json({ error: 'This code has expired. Please request a new one.' });
    }
    if (pending.attempts >= OTP_MAX_ATTEMPTS) {
      pendingOtps.delete(email);
      return res.status(429).json({ error: 'Too many incorrect attempts. Please request a new code.' });
    }

    const suppliedHash = Buffer.from(hash(otp), 'hex');
    const storedHash = Buffer.from(pending.hash, 'hex');
    const matches = suppliedHash.length === storedHash.length && timingSafeEqual(suppliedHash, storedHash);
    if (!matches) {
      pending.attempts += 1;
      const remaining = OTP_MAX_ATTEMPTS - pending.attempts;
      if (remaining <= 0) {
        pendingOtps.delete(email);
        return res.status(429).json({ error: 'Too many incorrect attempts. Please request a new code.' });
      }
      return res.status(401).json({ error: `Incorrect code. ${remaining} attempt(s) remaining.` });
    }

    pendingOtps.delete(email);
    try {
      const token = randomUUID();
      const sessionExpiresAtMs = Date.now() + 8 * 60 * 60_000;
      const expiresAt = new Date(sessionExpiresAtMs).toISOString();
      adminSessions.set(token, { email: SUPER_ADMIN_EMAIL, expiresAt: sessionExpiresAtMs });
      await insert(ctx, 'adminSessions', token, {
        id: token,
        tokenHash: hash(token),
        username: SUPER_ADMIN_USERNAME,
        email: SUPER_ADMIN_EMAIL,
        expiresAt,
        createdAt: new Date().toISOString(),
      });
      return res.json({
        ok: true,
        sessionToken: token,
        user: { id: 'super-admin', fullName: 'Super Admin', username: SUPER_ADMIN_USERNAME, email: SUPER_ADMIN_EMAIL, role: 'SuperAdmin', status: 'Active' },
      });
    } catch (e) {
      console.error('Admin login failed', e);
      return res.status(500).json({ error: 'Admin login failed.' });
    }
  });
  router.post('/logout', async (req, res) => { const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim(); if (token) { adminSessions.delete(token); try { const records = await rows(ctx, 'adminSessions'); const record = records.find((x: any) => String(x?.id) === token); if (record) await patch(ctx, 'adminSessions', token, { ...record, revokedAt: new Date().toISOString(), expiresAt: new Date(0).toISOString() }); } catch {} } return res.json({ ok: true }); });
  router.get('/students/pending', requireAdminSession(ctx), async (_req, res) => { try { return res.json({ students: (await rows(ctx, 'students')).filter((s: any) => String(s?.status || '').toLowerCase() === 'pending') }); } catch { return res.status(500).json({ error: 'Could not load pending students.' }); } });
  router.post('/students/:id/approve', requireAdminSession(ctx), async (req, res) => {
    const studentId = String(req.params.id);
    try {
      const students = await rows(ctx, 'students');
      const student = students.find((s: any) => String(s?.id) === studentId);
      if (!student) return res.status(404).json({ error: 'Student not found.' });
      if (String(student.status).trim().toLowerCase() !== 'pending') return res.status(409).json({ error: 'Student is not pending approval.' });
      const email = String(student.email || '').trim().toLowerCase();
      if (!email) return res.status(409).json({ error: 'Student email ID is required before approval.' });

      // Approval is independent from tablet assignment. If all tablets are busy,
      // the student is still approved and the Admin can assign a tablet later.
      const approvedAt = new Date().toISOString();
      const assignedTabletId = String(student.assignedTabletId ?? '').trim();
      const approved = { ...student, status: 'Approved', isActive: true, emailApproved: true, assignedTabletId: assignedTabletId || null, approvedAt, approvedBy: SUPER_ADMIN_EMAIL };
      await patch(ctx, 'students', studentId, approved);

      const logId = randomUUID();
      await insert(ctx, 'auditLogs', logId, { id: logId, action: 'STUDENT_APPROVED', studentId, email, by: SUPER_ADMIN_EMAIL, timestamp: approvedAt, tabletId: assignedTabletId || null });
      return res.json({ ok: true, student: approved, tablet: null, message: assignedTabletId ? 'Student approved and existing tablet assignment retained.' : 'Student approved successfully. Assign an available tablet when ready.' });
    } catch (e) { console.error('Approval failed', e); return res.status(500).json({ error: 'Student approval failed.' }); }
  });
  router.get('/checkout-requests', requireAdminSession(ctx), async (_req, res) => { try { const all = await rows(ctx, 'checkoutRequests'); const requests = all.filter((x: any) => String(x?.status || '').trim().toLowerCase() === 'pending').sort((a: any, b: any) => String(b?.requestedAt || '').localeCompare(String(a?.requestedAt || ''))); res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate'); return res.json({ requests, count: requests.length }); } catch { return res.status(500).json({ error: 'Could not load checkout requests.' }); } });
  router.post('/checkout-requests/:id/decision', requireAdminSession(ctx), async (req, res) => { const id = String(req.params.id); const decision = String(req.body?.decision || '').toLowerCase(); if (!['approved','rejected'].includes(decision)) return res.status(400).json({ error: 'Decision must be approved or rejected.' }); try { const requests = await rows(ctx, 'checkoutRequests'); const request = requests.find((x: any) => String(x?.id) === id); if (!request || String(request.status || '').toLowerCase() !== 'pending') return res.status(404).json({ error: 'Pending checkout request not found.' }); if (decision === 'rejected') { const updated = { ...request, status: 'rejected', decidedAt: new Date().toISOString(), decidedBy: SUPER_ADMIN_EMAIL }; await patch(ctx, 'checkoutRequests', id, updated); return res.json({ ok: true, request: updated }); } const sessions = await rows(ctx, 'studentSessions'); const session = sessions.find((x: any) => x?.status === 'active' && String(x.studentId) === String(request.studentId)); if (!session) return res.status(409).json({ error: 'Active student session not found.' }); const returnedAt = new Date().toISOString(); const durationMinutes = Math.max(0, Math.round((new Date(returnedAt).getTime() - new Date(session.startedAt).getTime()) / 60000)); await patch(ctx, 'studentSessions', String(session.id), { ...session, returnedAt, durationMinutes, status: 'returned', checkoutApprovedAt: returnedAt, checkoutApprovedBy: SUPER_ADMIN_EMAIL }); const attendanceRows = await rows(ctx, 'attendance'); const existingAttendance = attendanceRows.find((x: any) => String(x?.sessionId) === String(session.id) && String(x?.studentId) === String(session.studentId)); if (existingAttendance) await patch(ctx, 'attendance', String(existingAttendance.id), { ...existingAttendance, returnedAt, durationMinutes, status: 'OUT' }); else { const attendanceId = randomUUID(); await insert(ctx, 'attendance', attendanceId, { id: attendanceId, sessionId: session.id, studentId: session.studentId, studentName: session.studentName, tabletId: session.tabletId, startedAt: session.startedAt, returnedAt, durationMinutes, status: 'OUT', date: returnedAt.slice(0,10) }); } const tablets = await rows(ctx, 'tablets'); const tablet = tablets.find((t: any) => String(t?.id ?? t?.tabletId ?? t?.tabletNumber) === String(session.tabletId)); if (tablet) await patch(ctx, 'tablets', String(tablet.id ?? tablet.tabletId ?? tablet.tabletNumber), { ...tablet, status: 'Available', assignedStudentId: null, assignedStudentName: null, assignedToStudentId: null, assignedToStudentName: null }); const students = await rows(ctx, 'students'); const student = students.find((s: any) => String(s?.id) === String(session.studentId)); if (student) await patch(ctx, 'students', String(student.id), { ...student, assignedTabletId: null, status: 'Approved' }); const updatedRequest = { ...request, status: 'approved', decidedAt: returnedAt, decidedBy: SUPER_ADMIN_EMAIL }; await patch(ctx, 'checkoutRequests', id, updatedRequest); return res.json({ ok: true, request: updatedRequest }); } catch (e) { console.error('Checkout decision failed', e); return res.status(500).json({ error: 'Checkout decision failed.' }); } });
  return router;
}
