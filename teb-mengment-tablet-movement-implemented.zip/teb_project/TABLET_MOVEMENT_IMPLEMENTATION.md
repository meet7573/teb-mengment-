# Tablet Movement Management Module

Implemented features:
- Student authenticated movement request and personal history
- Vacation, Take Home, Holiday, Educational Purpose and Other movement types
- Strict active-assignment and duplicate-active-movement validation
- Admin movement dashboard with search, status filtering and workflow actions
- PENDING -> APPROVED/REJECTED -> OUTSIDE -> RETURNED workflow
- Automatic OVERDUE status calculation
- Check-out condition, existing damage, battery condition and admin remarks
- Check-in condition, new damage and remarks
- Admin and student API separation
- Audit log records for request and all admin actions

Collections:
- tabletMovements

Run:
1. npm install
2. npm run dev

The server requires the existing Supabase environment configuration.
