# Deployment guide

This project is a React + Vite app with an Express server wrapper.

## Render
Build Command:
npm run build

Start Command:
npm start

The server has been updated to use the hosting provider's PORT automatically.

## Environment variables
See `.env.example`. Do not commit real secrets to GitHub.
